package TutExercise.T1;

public interface Account {

    void deposit(int x);

    boolean withdraw(int y);
}
